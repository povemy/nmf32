import { db } from "@/lib/db";
import { handle, ok, ApiError } from "@/lib/api";
import { requireActiveSellerStore } from "@/lib/auth";
import { parseJson } from "@/lib/json";

export const dynamic = "force-dynamic";

// POST /api/store/webhooks/[id]/test — create a demo delivery (sandbox: no real HTTP call).
export const POST = handle(async (_req: Request, ctx: { params: Promise<{ id: string }> }) => {
  const { store } = await requireActiveSellerStore();
  const { id } = await ctx.params;
  const endpoint = await db.webhookEndpoint.findFirst({ where: { id, storeId: store.id } });
  if (!endpoint) throw new ApiError(404, "NOT_FOUND", "Webhook endpoint not found");

  const events = parseJson<string[]>(endpoint.eventsJson, ["order.paid"]);
  const event = "webhook.test";
  const payload = {
    event,
    storeSlug: store.slug,
    subscribedEvents: events,
    demo: true,
    sentAt: new Date().toISOString(),
  };

  const delivery = await db.webhookDelivery.create({
    data: {
      endpointId: endpoint.id,
      event,
      payloadJson: JSON.stringify(payload),
      status: "success",
      attempts: 1,
      responseCode: 200,
      lastAttemptAt: new Date(),
    },
  });

  return ok(delivery, { status: 201 });
});
